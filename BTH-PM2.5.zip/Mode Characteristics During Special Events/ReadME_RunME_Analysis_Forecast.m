%% Instructions for Koopman Modes.

clc; clear variables; close all;
Poi_Daily=GenerateKoopmanModes('Poi_Day_mean',1,3,0);







